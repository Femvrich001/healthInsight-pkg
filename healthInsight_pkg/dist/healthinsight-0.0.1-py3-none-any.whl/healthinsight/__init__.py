__version__ = "0.0.1"
from .Calculations import HealthCalc

bmi = HealthCalc.bmi
bai = HealthCalc.bai
bsi = HealthCalc.bsi
tbw = HealthCalc.tbw
corpulence_index = HealthCalc.corpulence_index
waist_to_hip = HealthCalc.waist_to_hip
pignet_index = HealthCalc.pignetindex
perinatal_mortality = HealthCalc.perinatal_mortality
maternal_mortality_ratio = HealthCalc.maternal_mortality_ratio
infant_mortality = HealthCalc.infant_mortality
birthrate = HealthCalc.birthrate
